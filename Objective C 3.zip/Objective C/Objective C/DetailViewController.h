//
//  DetailViewController.h
//  Objective C
//
//  Created by Yogesh Patel on 22/09/21.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface DetailViewController : UIViewController

@property (strong, nonatomic) NSString *name;//let name = ""

@end

NS_ASSUME_NONNULL_END
