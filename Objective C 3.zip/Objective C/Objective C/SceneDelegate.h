//
//  SceneDelegate.h
//  Objective C
//
//  Created by Yogesh Patel on 13/09/21.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

