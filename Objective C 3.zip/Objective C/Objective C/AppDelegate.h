//
//  AppDelegate.h
//  Objective C
//
//  Created by Yogesh Patel on 13/09/21.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

