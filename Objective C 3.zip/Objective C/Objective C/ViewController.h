//
//  ViewController.h
//  Objective C
//
//  Created by Yogesh Patel on 13/09/21.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (strong, nonatomic) NSString * strName;
//let strName = ""
@end

